const archiver = require('archiver');

// Helper: extract filename from URL
function extractFilename(url, fallback = 'document.pdf') {
  try {
    const u = new URL(url);
    const fn = u.searchParams.get('fn');
    if (fn) return fn.endsWith('.pdf') ? fn : fn + '.pdf';
    const parts = u.pathname.split('/').filter(Boolean);
    const last = parts[parts.length - 1];
    if (last && last.includes('.')) return last;
  } catch (_) {}
  return fallback;
}

// Helper: generate PDF using playwright instead of puppeteer
async function generatePDF(url) {
  const { chromium } = require('playwright-core');
  const chromiumModule = require('@sparticuz/chromium');

  const browser = await chromium.launch({
    args: chromiumModule.args,
    executablePath: await chromiumModule.executablePath(),
    headless: true,
  });

  const context = await browser.newContext({
    userAgent:
      'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 Chrome/120 Safari/537.36',
  });

  const page = await context.newPage();

  try {
    await page.goto(url, { waitUntil: 'networkidle', timeout: 30000 });
    await page.waitForTimeout(2000);

    const pdf = await page.pdf({
      format: 'A4',
      printBackground: true,
      margin: { top: '10mm', bottom: '10mm', left: '10mm', right: '10mm' },
    });

    return pdf;
  } finally {
    await page.close();
    await context.close();
    await browser.close();
  }
}

// Main Vercel handler
module.exports = async (req, res) => {
  res.setHeader('Access-Control-Allow-Origin', '*');
  res.setHeader('Access-Control-Allow-Methods', 'POST, OPTIONS');
  res.setHeader('Access-Control-Allow-Headers', 'Content-Type');

  if (req.method === 'OPTIONS') return res.status(200).end();
  if (req.method !== 'POST')
    return res.status(405).json({ error: 'Method not allowed' });

  const { url, urls } = req.body || {};
  const isBulk = Array.isArray(urls) && urls.length > 0;
  const isSingle = typeof url === 'string' && url.length > 0;

  if (!isSingle && !isBulk)
    return res
      .status(400)
      .json({ error: 'Provide url (single) or urls[] in body' });

  if (isBulk && urls.length > 5)
    return res
      .status(400)
      .json({ error: 'Max 5 URLs per bulk request. Run in batches.' });

  try {
    // ── Single PDF ────────────────────────────────────────────────────────────
    if (isSingle) {
      const filename = extractFilename(url);
      const pdf = await generatePDF(url);
      res.setHeader('Content-Type', 'application/pdf');
      res.setHeader(
        'Content-Disposition',
        `attachment; filename="${filename}"`
      );
      res.setHeader('Content-Length', pdf.length);
      return res.status(200).send(Buffer.from(pdf));
    }

    // ── Bulk PDFs → ZIP ───────────────────────────────────────────────────────
    res.setHeader('Content-Type', 'application/zip');
    res.setHeader(
      'Content-Disposition',
      'attachment; filename="documents.zip"'
    );

    const archive = archiver('zip', { zlib: { level: 6 } });
    archive.pipe(res);

    for (let i = 0; i < urls.length; i++) {
      const entry =
        typeof urls[i] === 'string' ? { url: urls[i] } : urls[i];
      const filename = extractFilename(entry.url, `document_${i + 1}.pdf`);
      try {
        const pdf = await generatePDF(entry.url);
        archive.append(Buffer.from(pdf), { name: filename });
      } catch (err) {
        console.error(`Failed: ${entry.url}`, err.message);
      }
    }

    await archive.finalize();
  } catch (err) {
    console.error('PDF generation error:', err);
    if (!res.headersSent)
      res.status(500).json({ error: err.message });
  }
};
